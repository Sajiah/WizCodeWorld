import pymongo, bcrypt
from pymongo import MongoClient
import humanize
import datetime
from bson import ObjectId

class Posts:
    def __init__(self):
        self.client = MongoClient()
        self.db = self.client.codewizard
        self.Users = self.db.users
        self.Posts = self.db.posts
        self.Comments = self.db.comments

    def insert_post(self, data):
        inserted = self.Posts.insert({"username": data.username, "content": data.content, "date-added":
            datetime.datetime.now()})
        return True

    def get_all_posts(self, user):
        all_posts = self.Posts.find()
        new_posts = []
        for post in all_posts:
            post["user"] = self.Users.find_one({"username": post["username"]})

            if post["user"] != None :
                print(post["user"]["avatar"])
            post["timestamp"] = humanize.naturaltime(datetime.datetime.now() - post["date-added"])
            post["old_comments"] = self.Comments.find({"post_id": str(post["_id"])})
            post["comment"] = []

            for comment in post["old_comments"]:
                comment["user"] = self.Users.find_one({"username": comment["username"]})
                print(comment["user"]["avatar"])
                comment["timestamp"] = humanize.naturaltime(datetime.datetime.now() - comment["date-added"])
                post["comment"].append(comment)

            new_posts.append(post)

        return new_posts

    def get_user_posts(self, user):
        user_posts = self.Posts.find({"username": user})
        new_posts = []
        for post in user_posts:
            if user:
                post["user"] = self.Users.find_one({"username": user})
                print(post)
                new_posts.append(post)

        return new_posts

    def add_comment(self, comment):

        inserted = self.Comments.insert({"post_id": comment.post_id, "comment": comment.comment,
                                        "date-added": datetime.datetime.now(), "username": comment.username})

        return inserted





