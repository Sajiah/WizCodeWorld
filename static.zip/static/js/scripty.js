

$(document).ready(function(){
    console.log("loaded");
    $.material.init();
});

$(document).on("submit", "#register-form", function(e){
        e.preventDefault();
        var form = $("#register-form").serialize();
        $.ajax({
            url: '/postregistration',
            type: 'POST',
            data: form,
            success: function(res){
                 if(res == "success") {
                    alert("Successfully Registered!");
                    window.location.href = '/'
                }
                else{
                    alert("Could not Register")
                }

            }

        });
 });


 $(document).on("submit", "#login-form", function(e){
        e.preventDefault();
        var form = $("#login-form").serialize();
        $.ajax({
            url: '/check-login',
            type: 'POST',
            data: form,
            success: function(res){
                if(res == "error"){
                    alert("Could not login")
                }
                else{
                    window.location.href = '/'
                }


            }

        });
 });

 $(document).on("click", "#logout-link", function(e){
        e.preventDefault();
        $.ajax({
            url: '/logout',
            type: 'GET',
            success: function(res){
                if(res == "success"){
                    window.location.href = '/';
                }
                else{
                    alert("Something went wrong")
                }


            }

        });
 });

  $(document).on("submit", "#post-activity", function(e){
        e.preventDefault();
        form = $(this).serialize();
        $.ajax({
            url: '/post-activity',
            type: 'POST',
            data: form,
            success: function(res){
                console.log(res);


            }

        });
  });

//
//    $('.grid').isotope({
//      itemSelector: '.grid-item',
//      masonry: {
//        columnWidth: 100
//      }
//    });
//



 $(document).on("click", "#settings-button", function(e){

        console.log("im in here");
        e.preventDefault();
        var form = $("#settings-form").serialize();
        $.ajax({
            url: '/update-settings',
            type: 'POST',
            data: form,
            success: function(res){
                if(res == "success"){
                    window.location.href = window.location.href
                }
                else{
                    console.log(res);
                }


            }

        });
 });


 $(document).on("submit", ".comment-form", function(e){
    e.preventDefault();
    var form = $(this).serialize();
    console.log(form);
    $.ajax({
        url: '/submit-comment',
        type: 'POST',
        data: form,
        success: function(res){
            console.log(res);
        }

    });

 });